import 'dart:convert';

import 'package:http/http.dart' as http;

import '../constants.dart';
import '../models/product.dart';

class ProductService {
  String get _host {
    final value = host;
    if (value == null || value.trim().isEmpty) {
      throw Exception('HOST is not configured in assets/.env');
    }
    return value.replaceFirst(RegExp(r'/+$'), '');
  }

  Future<List<Product>> getAllProducts() async {
    final response = await http.get(Uri.parse('$_host/products'));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);

      final List productsJson = data['products'] ?? [];

      return productsJson.map((json) => Product.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load products');
    }
  }

  Future<Product> getProductById(int productId) async {
    final response = await http.get(
      Uri.parse('$_host/products/$productId'),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);

      return Product.fromJson(data);
    } else {
      throw Exception('Failed to load product with ID $productId');
    }
  }
}
