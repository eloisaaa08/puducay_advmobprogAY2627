void login() async {
  UserService userService = UserService();

  setState(() {
    _isLoading = true;
  });

  if (_formKey.currentState!.validate()) {
    try {
      final response = await userService.loginUser(
        _usernameController.text,
        _passwordController.text,
      );

      // Save user data to SharedPreferences
      await userService.saveUserData(response);

      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });

      Navigator.pushReplacementNamed(context, '/home', arguments: response);
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Login failed: ${e.toString()}')));
    }
  }
}
