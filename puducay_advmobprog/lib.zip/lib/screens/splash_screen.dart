Future<void> _checkAuthentication() async {
  await Future.delayed(const Duration(milliseconds: 1500));

  final loggedIn = await _userService.isLoggedIn();

  if (!mounted) return;

  if (loggedIn) {
    final userData = await _userService.getUserData();
    if (!mounted) return;

    Navigator.pushReplacementNamed(context, '/home', arguments: userData);
  } else {
    Navigator.pushReplacementNamed(context, '/signin');
  }
}
